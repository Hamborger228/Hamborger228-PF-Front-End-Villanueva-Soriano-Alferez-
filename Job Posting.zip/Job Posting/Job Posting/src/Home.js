import useFetch from "./useFetch";
import JobList from "./JobList";

const Home = () => {
    const { error, isPending, data} = useFetch('http://localhost:8000/Job')

    return ( 
        <div className="home">
            { error && <div>{ error }</div> }
            { isPending && <div>Loading...</div> }
            {data && <JobList  FilterJob={data} />}

        </div>
        
     );
}
 
export default Home;